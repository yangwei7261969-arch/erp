import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        { error: '用户名和密码不能为空' },
        { status: 400 }
      );
    }

    const client = getSupabaseClient();

    // 支持用户名或邮箱登录
    // 先尝试用用户名查询
    let query = client
      .from('users')
      .select('*')
      .eq('status', 'active');

    // 判断是邮箱还是用户名
    if (username.includes('@')) {
      query = query.eq('email', username);
    } else {
      query = query.eq('username', username);
    }

    const { data: users, error } = await query
      .eq('password', password)
      .maybeSingle();

    if (error || !users) {
      return NextResponse.json(
        { error: '用户名或密码错误' },
        { status: 401 }
      );
    }

    // 更新最后登录时间
    await client
      .from('users')
      .update({ last_login_at: new Date().toISOString() })
      .eq('id', users.id);

    // 返回用户信息（不包含密码）
    const { password: _, ...userWithoutPassword } = users;

    return NextResponse.json({
      success: true,
      user: userWithoutPassword,
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: '登录失败，请稍后重试' },
      { status: 500 }
    );
  }
}
